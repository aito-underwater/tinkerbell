:orphan:

***************
NumPy internals
***************

.. This document has been moved to ../dev/internals.rst.

This document has been moved to :ref:`numpy-internals`.

