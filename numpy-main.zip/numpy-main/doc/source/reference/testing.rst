.. _testing-guidelines:

Testing Guidelines
==================

.. include:: ../../TESTS.rst
   :start-line: 6
